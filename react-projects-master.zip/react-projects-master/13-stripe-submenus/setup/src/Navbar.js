import React from 'react'
import logo from './images/logo.svg'
import { FaBars } from 'react-icons/fa'

const Navbar = () => {
  return <h2>navbar component</h2>
}

export default Navbar
